var APE = {
	'version': '1.1',
	'Request': {},
	'Transport': {}
};
